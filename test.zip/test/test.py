#%%

import apmtools.data_processing as dtp
import apmtools.functions as fn
import apmtools.classes as cls


import os as os
import datetime as dt

#%%

upas =cls.DictionaryPlus()

directory = r'./DAY 3/CLASS 1/STATIONARY/UPAS/'
file = 'PSP00164_LOG_2024-03-22T07_00_45UTC_S1_C1___________8AG_______.txt'

upas[file] = dtp.upas_processing(directory,file)
upas[file].meta = {'id':'PSP00164','location':'Classroom 1','type':'stationary'}

directory = r'./DAY 3/CLASS 1/LEARNER/UPAS/'
file = 'PSP00161_LOG_2024-03-22T06_58_23UTC_S1_C1_L3________8DB_______.txt'

upas[file] = dtp.upas_processing(directory, file)
upas[file].meta = {'id': 'PSP00161',
                   'location': 'Classroom 1', 'type': 'personal'}

directory = r'./DAY 3/KITCHEN/COOK/UPAS/'
file = 'PSP00174_LOG_2024-03-21T14_09_17UTC_S1_K1_P3________8D4_______.txt'

upas[file] = dtp.upas_processing(directory, file)
upas[file].meta = {'id': 'PSP00174',
                   'location': 'Kitchen', 'type': 'personal'}

print(upas.set_attrib('id'))

print(upas.show().start)

first_upas = upas.show()

print(type(first_upas))

print(first_upas.date_time_filter(date_start = first_upas.start+dt.timedelta(hours=1)).start)

print(len(upas.subset({'type':['personal'],'location':['Classroom 2']})))


# %%
